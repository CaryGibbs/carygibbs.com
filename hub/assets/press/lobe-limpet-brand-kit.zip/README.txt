LOBE LIMPET BRAND KIT
=====================

Name: Lobe Limpet (two words, capital L for each in sentences; the logo is
lowercase "lobe limpet"). Our mascot is Lobey.
Tagline: Knowledge that sticks.
Website: lobelimpet.com   Press and brand questions: support@lobelimpet.com

logos/  Logos as SVG (scales to any size) and PNG (transparent).
        "-white" versions are for dark backgrounds.
lobey/  Lobey the mascot. SVG files are animated (in web browsers),
        GIFs are animated anywhere, PNGs are still images.

Colours
  Limpet coral   #FF7A59
  Deep water     #123A4A
  Rock           #5D7C89
  Rock pool      #D4F1EA
  Sand           #FFF8EF
  Sunny yellow   #FFC94A
  Sea green      #2A9D8F

Fonts: Fredoka (logo), Plus Jakarta Sans (headings), Inter (text).
All free from Google Fonts.

Please don't stretch, recolour, rotate or add effects to the logo, and keep
some clear space around it. Please don't redraw Lobey or put words in
Lobey's mouth that we wouldn't say.
